import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        // Remplacez par votre URL, nom d'utilisateur et mot de passe
        String url = "jdbc:postgresql://localhost:5432/gestion_dechets"; // nom de la base de données
        String user = "postgres"; // nom d'utilisateur
        String password = "yakfis226"; // mot de passe

        Connection connection = null;

        try {
            // Établir la connexion
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion réussie !");
            // Ici, vous pouvez exécuter vos opérations sur la base de données

        } catch (SQLException e) {
            System.out.println("Erreur de connexion : " + e.getMessage());
        } finally {
            // Fermer la connexion
            if (connection != null) {
                try {
                    connection.close();
                    System.out.println("Connexion fermée.");
                } catch (SQLException e) {
                    System.out.println("Erreur lors de la fermeture de la connexion : " + e.getMessage());
                }
            }
        }
    }
}
