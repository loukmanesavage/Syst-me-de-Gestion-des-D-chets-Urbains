package gestion_dechets.entites;

public class Citoyen {
    private int id;
    private String nom;
    private String adresse;
    private String typeDechets;


public Citoyen( int Id, String nom, String adresse, String typeDechets){

    this.nom = nom;
    this.adresse = adresse;
    this.typeDechets = typeDechets;
    this.id = Id;


}

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getTypeDechets() {
        return typeDechets;
    }

    public void setId(int id) {
        id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setTypeDechets(String typeDechets) {
        this.typeDechets = typeDechets;
    }


    @Override
    public String toString() {
        return "Citoyen{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", adresse='" + adresse + '\'' +
                ", typeDechets='" + typeDechets + '\'' +
                '}';
    }

    // Getters et Setters ici si nécessaire
}



