package gestion_dechets.entites;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
//Creation de la classe collectte
public class Collecte {
    private LocalDate dateCollecte;
    private Camion camionCollecteur;
    private ZoneGeographique zoneConcerner;
    private List<PointCollecte> pointCollecte;
    private String typeDechet;

    //Constructeur pour l'initialisation des attribut
    public Collecte(LocalDate dateCollecte, Camion camionCollecteur, ZoneGeographique zoneConcerner, List pointCollecte, String typeDechet){
        this.dateCollecte = dateCollecte;
        this.camionCollecteur = camionCollecteur;
        this.zoneConcerner = zoneConcerner;
        this.pointCollecte = pointCollecte;
        this.typeDechet = typeDechet;

    }
    //getters et setters pour l'acces et la modification des attributs


    public LocalDate getDateCollecte() {
        return dateCollecte;
    }

    public Camion getCamionCollecteur() {
        return camionCollecteur;
    }

    public ZoneGeographique getZoneConcerner() {
        return zoneConcerner;
    }

    public List<PointCollecte> getPointCollecte() {
        return pointCollecte;
    }

    public String getTypeDechet() {
        return typeDechet;
    }

    public void setDateCollecte(LocalDate dateCollecte) {
        this.dateCollecte = dateCollecte;
    }

    public void setCamionCollecteur(Camion camionCollecteur) {
        this.camionCollecteur = camionCollecteur;
    }

    public void setZoneConcerner(ZoneGeographique zoneConcerner) {
        this.zoneConcerner = zoneConcerner;
    }

    public void setPointCollecte(List<PointCollecte> pointCollecte) {
        this.pointCollecte = pointCollecte;
    }

    public void setTypeDechet(String typeDechet) {
        this.typeDechet = typeDechet;
    }
    @Override
    public String toString() {
        return "Collecte{" +
                "dateCollecte=" + dateCollecte +
                ", camionCollecteur=" + camionCollecteur +
                ", zoneConcerner=" + zoneConcerner +
                ", pointCollecte=" + pointCollecte +
                ", typeDechet='" + typeDechet + '\'' +
                '}';
    }




}
