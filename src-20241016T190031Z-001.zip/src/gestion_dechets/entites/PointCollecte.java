package gestion_dechets.entites;
//Creation de la classe pointcollecte
public class PointCollecte {

    private int id;
    private float pourcentageRemplissage;
    private String typeDechets;

   //Initialisation des attributs
    public PointCollecte(int id, float pourcentageRemplissage, String typeDechets){

        this.id = id;
        this.pourcentageRemplissage = pourcentageRemplissage;
        this.typeDechets = typeDechets;

    }

    //getters et setters pour acceder et modifier les attributs


    public int getId() {
        return id;
    }

    public float getPourcentageRemplissage() {
        return pourcentageRemplissage;
    }

    public String getTypeDechets() {
        return typeDechets;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPourcentageRemplissage(float pourcentageRemplissage) {
        this.pourcentageRemplissage = pourcentageRemplissage;
    }

    public void setTypeDechets(String typeDechets) {
        this.typeDechets = typeDechets;
    }
}
