package gestion_dechets.entites;
//Declaration de la classe camion
public class Camion {
    private String immatriculation;
    private String typeDechets;
    private float distanceParcouru;
    private float capaciteCamion;

    //utilisation des constructeur pour obtenir les attributs

    public Camion(String immatriculation, String typeDechets, float distanceParcouru, float capaciteCamion){

        this.immatriculation = immatriculation;
        this.typeDechets = typeDechets;
        this.distanceParcouru = distanceParcouru;
        this.capaciteCamion = capaciteCamion;

    }


//Utilisation des getters pour obtenir les attributs
    public String getImmatriculation() {
        return immatriculation;
    }

    public String getTypeDechets() {
        return typeDechets;
    }

    public float getDistanceParcouru() {
        return distanceParcouru;
    }

    public float getCapaciteCamion() {
        return capaciteCamion;
    }

    //utilisations des setters pour modifier les attributs

    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }

    public void setTypeDechets(String typeDechets) {
        this.typeDechets = typeDechets;
    }

    public void setDistanceParcouru(float distanceParcouru) {
        this.distanceParcouru = distanceParcouru;
    }

    public void setCapaciteCamion(float capaciteCamion) {
        this.capaciteCamion = capaciteCamion;
    }
}
