package gestion_dechets.entites;

public class RapportCollecte {
    private int id;
    private Collecte collecte;
    private float tauxRemplissage;
    private float quantiteDechet;


    public RapportCollecte(int id, Collecte collecte, float tauxRemplissage, float quantiteDechet){
        this.id = id;
        this.collecte = collecte;
        this.tauxRemplissage = tauxRemplissage;
        this.quantiteDechet = quantiteDechet;

    }

    public int getId() {
        return id;
    }

    public Collecte getCollecte() {
        return collecte;
    }

    public float getTauxRemplissage() {
        return tauxRemplissage;
    }

    public float getQuantiteDechet() {
        return quantiteDechet;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCollecte(Collecte collecte) {
        this.collecte = collecte;
    }

    public void setTauxRemplissage(float tauxRemplissage) {
        this.tauxRemplissage = tauxRemplissage;
    }

    public void setQuantiteDechet(float quantiteDechet) {
        this.quantiteDechet = quantiteDechet;
    }

    //representation textuelle de lobjet RapportCollecte

   @Override
   public String toString(){
        return "RapportCollecte{"+
                "id = " +id +
                ", tauxRemplissage =" + tauxRemplissage +
                ",quantiteDechet =" + quantiteDechet + '\'' +
                '}';



   }
}
