package gestion_dechets.entites;
//creation de la classe zoneGeographique
public class ZoneGeographique {

    private String nomZone;
    private String frequenceCollectte;

    //Construction des attributs

    public ZoneGeographique(String nomZone, String frequenceCollectte){
        this.nomZone = nomZone;
        this.frequenceCollectte = frequenceCollectte;

    }

    //getters et setters pour acceder et modifier les attributs


    public String getNomZone() {
        return nomZone;
    }

    public String getFrequenceCollectte() {
        return frequenceCollectte;
    }

    public void setNomZone(String nomZone) {
        this.nomZone = nomZone;
    }

    public void setFrequenceCollectte(String frequenceCollectte) {
        this.frequenceCollectte = frequenceCollectte;
    }



    @Override
    public String toString() {
        return "ZoneGeographique{" +
                "nomZone='" + nomZone + '\'' +
                ", frequenceCollecte='" + frequenceCollectte + '\'' +
                '}';
    }



}
