package gestion_dechets.entites.ui;



import gestion_dechets.entites.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GestionCollecteUI extends JFrame {
    // Instance de la classe de gestion de collecte, qui contient la logique métier.
    private GestionCollecte gestionCollecte;

    // Constructeur de la classe, initialisant l'interface graphique.
    public GestionCollecteUI() {
        gestionCollecte = new GestionCollecte(); // Initialise la gestion des collectes.
        initUI(); // Appelle la méthode pour configurer l'interface utilisateur.
    }

    // Méthode pour configurer l'interface utilisateur.
    private void initUI() {
        setTitle("Gestion de Collecte de Déchets"); // Titre de la fenêtre.
        setSize(600, 400); // Taille de la fenêtre.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Fermer l'application lorsque la fenêtre est fermée.
        setLocationRelativeTo(null); // Centre la fenêtre sur l'écran.

        // Création des onglets pour chaque entité (Citoyens, Camions, Points de Collecte, Zones Géographiques).
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.add("Citoyens", createCitoyenPanel());
        tabbedPane.add("Camions", createCamionPanel());
        tabbedPane.add("Points de Collecte", createPointCollectePanel());
        tabbedPane.add("Zones Géographiques", createZoneGeographiquePanel());

        add(tabbedPane); // Ajoute le panneau à la fenêtre principale.
    }

    // Méthode pour créer le panneau de gestion des citoyens.
    private JPanel createCitoyenPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10)); // Crée un panneau avec un layout en grille (5 lignes, 2 colonnes).
        JTextField idField = new JTextField(); // Champ de texte pour l'identifiant du citoyen.
        JTextField nomField = new JTextField(); // Champ de texte pour le nom du citoyen.
        JTextField adresseField = new JTextField();
        JTextField typeDechetsField = new JTextField();// Champ de texte pour l'adresse du citoyen.
        JButton addButton = new JButton("Ajouter Citoyen"); // Bouton pour ajouter un citoyen.

        // Ajoute une action au bouton pour ajouter un citoyen lorsque cliqué.
        addButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText()); // Récupère et convertit l'identifiant en entier.
            String nom = nomField.getText(); // Récupère le nom.
            String adresse = adresseField.getText();
            String typeDechets = typeDechetsField.getText();// Récupère l'adresse.
            Citoyen citoyen = new Citoyen(id, nom, adresse, typeDechets); // Crée un nouvel objet Citoyen.
            gestionCollecte.ajoutCitoyens(citoyen); // Ajoute le citoyen à la gestion de collecte.
            JOptionPane.showMessageDialog(this, "Citoyen ajouté !"); // Affiche un message de confirmation.
        });

        // Ajoute les champs et le bouton au panneau.
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Nom:"));
        panel.add(nomField);
        panel.add(new JLabel("Adresse:"));
        panel.add(adresseField);
        panel.add(new JLabel("Type Dechets:"));
        panel.add(typeDechetsField);
        panel.add(addButton);

        return panel; // Retourne le panneau complet pour les citoyens.
    }

    // Méthode pour créer le panneau de gestion des camions.
    private JPanel createCamionPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10)); // Crée un panneau avec un layout en grille.
        JTextField immatriculationField = new JTextField(); // Champ pour l'immatriculation.
        JTextField typeDechetsField = new JTextField(); // Champ pour le type de déchets transportés.
        JTextField distanceField = new JTextField(); // Champ pour la distance parcourue.
        JTextField capaciteField = new JTextField(); // Champ pour la capacité.
        JButton addButton = new JButton("Ajouter Camion"); // Bouton pour ajouter un camion.

        // Ajoute une action au bouton pour ajouter un camion.
        addButton.addActionListener(e -> {
            String immatriculation = immatriculationField.getText();
            String typeDechets = typeDechetsField.getText();
            float distance = Float.parseFloat(distanceField.getText());
            float capacite = Float.parseFloat(capaciteField.getText());
            Camion camion = new Camion(immatriculation, typeDechets, distance, capacite);
            gestionCollecte.ajoutCamion(camion);
            JOptionPane.showMessageDialog(this, "Camion ajouté !");
        });

        // Ajoute les champs et le bouton au panneau.
        panel.add(new JLabel("Immatriculation:"));
        panel.add(immatriculationField);
        panel.add(new JLabel("Type de Déchets:"));
        panel.add(typeDechetsField);
        panel.add(new JLabel("Distance Parcourue:"));
        panel.add(distanceField);
        panel.add(new JLabel("Capacité:"));
        panel.add(capaciteField);
        panel.add(addButton);

        return panel;
    }

    // Méthode pour créer le panneau de gestion des points de collecte.
    private JPanel createPointCollectePanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField idField = new JTextField();
        JTextField pourcentageField = new JTextField();
        JTextField typeDechetsField = new JTextField();
        JButton addButton = new JButton("Ajouter Point de Collecte");

        addButton.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            float pourcentage = Float.parseFloat(pourcentageField.getText());
            String typeDechets = typeDechetsField.getText();
            PointCollecte pointCollecte = new PointCollecte(id, pourcentage, typeDechets);
            gestionCollecte.ajoutPointCollectte(pointCollecte);
            JOptionPane.showMessageDialog(this, "Point de Collecte ajouté !");
        });

        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Pourcentage de Remplissage:"));
        panel.add(pourcentageField);
        panel.add(new JLabel("Type de Déchets:"));
        panel.add(typeDechetsField);
        panel.add(addButton);

        return panel;
    }

    // Méthode pour créer le panneau de gestion des zones géographiques.
    private JPanel createZoneGeographiquePanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nomZoneField = new JTextField();
        JTextField frequenceField = new JTextField();
        JButton addButton = new JButton("Ajouter Zone Géographique");

        addButton.addActionListener(e -> {
            String nomZone = nomZoneField.getText();
            String frequence = frequenceField.getText();
            ZoneGeographique zoneGeographique = new ZoneGeographique(nomZone, frequence);
            gestionCollecte.ajoutZoneGeographique(zoneGeographique);
            JOptionPane.showMessageDialog(this, "Zone Géographique ajoutée !");
        });

        panel.add(new JLabel("Nom de la Zone:"));
        panel.add(nomZoneField);
        panel.add(new JLabel("Fréquence de Collecte:"));
        panel.add(frequenceField);
        panel.add(addButton);

        return panel;
    }

    // Méthode principale pour lancer l'application.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GestionCollecteUI ui = new GestionCollecteUI(); // Crée une instance de l'interface utilisateur.
            ui.setVisible(true); // Rend la fenêtre visible.
        });
    }
}

