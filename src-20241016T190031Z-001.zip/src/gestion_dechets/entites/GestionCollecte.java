package gestion_dechets.entites;

import java.util.ArrayList;  //pour importer la classe ArrayList afin d'utiliser les liste dynamiques;
import java.util.List;   //Importation de l'interface List


//creation d'une liste GestionCollecte pour stocker les camions,citoyens,zone et point collecte
public class GestionCollecte {
//Initialisation des listes

    private List<Citoyen> citoyens;
    private List<Camion> camions;
    private List<PointCollecte> pointCollectes;
    private List<ZoneGeographique> zoneGeographiques;

//Construction de la classe GestionColecte

    public GestionCollecte(){

        citoyens = new ArrayList<>();    //La liste ds citoyens
        camions = new ArrayList<>();     //La liste ds camions
        pointCollectes = new ArrayList<>(); //La liste ds point de collecte
        zoneGeographiques = new ArrayList<>();   //La liste ds zone geographique

    }

  //Creation d'une methode pour ajouter un citoyen a la liste des citoyen
    public void ajoutCitoyens(Citoyen citoyen){

        citoyens.add(citoyen);  //permet d'ajouter un citoyen

    }
    public void modifierCitoyen(Citoyen citoyen){
        //parcour de la liste a la recherche du citoyen a modifier
        for (int i = 0; i < citoyens.size(); i++){
            Citoyen c = citoyens.get(i); //recuperation du citoyen a l'index i
           //verifie si le citoyen trouver possede le mme ID que celui passé en parametre
            if (c.getId() == citoyen.getId()){

                citoyens.set(i, citoyen); //remplace l'ancien citoyen par le nouveau
                break; //quite la boucle apres la modification

            }






        }



    }
    public void supprimerCitoyen(Citoyen citoyen){

        citoyens.remove(citoyen);

    }
    //Creation d'une methode pour ajouter un camion a la liste des citoyen
    public void ajoutCamion(Camion camion){

        camions.add(camion);  //permet d'ajouter un citoyen

    }
    public void modifierCamion(Camion camion){
//Parcour de la liste des camions a la recherche de celui desirer
        for (int i = 0; i < camions.size(); i++){

            Camion c = camions.get(i); //Recupere le camion a l'index i
            if (c.getImmatriculation() == camion.getImmatriculation()){
                //verifie si le camion trouver a le meme immatricualtion que celui rechercher

                //on le remplace par le nouveau
                camions.set(i, camion);
                break;

            }


        }

    }
    public void supprimerCamion(Camion camion){

        camions.remove(camion);

    }

    //Creation d'une methode pour ajouter un point de collecte a la liste des point de collecte
    public void ajoutPointCollectte(PointCollecte pointCollecte){

        pointCollectes.add(pointCollecte);  //permet d'ajouter un citoyen

    }
    public void modifierPointCollecte(PointCollecte pointCollectte){
//parcour de la liste des point de collecte
                 for (int i  = 0; i < pointCollectes.size(); i++){
                     //recuperation du point de collecte a l'index i
                     PointCollecte p = pointCollectes.get(i);
                     //verifie si le point de collecte trouver a le mme id que celui rechercher
                     if (p.getId() == pointCollectte.getId()){

                         pointCollectes.set(i, pointCollectte);//remplace le point trouver par le nouveau
                         break;



                     }



                 }
    }
    public void supprimerPointCollectte(PointCollecte pointCollecte){

        pointCollectes.remove(pointCollecte);

    }


    //Creation d'une methode pour ajouter une zone  a la liste des zone
    public void ajoutZoneGeographique(ZoneGeographique zoneGeographique){

        zoneGeographiques.add(zoneGeographique);  //permet d'ajouter un citoyen

    }
    public void modifierZoneGeographique(ZoneGeographique zoneGeographique){
//parcour de la liste des zones dispo
                   for(int i = 0; i < zoneGeographiques.size(); i++){
//recuperation de la zone a l'index i
                       ZoneGeographique z = zoneGeographiques.get(i);
                    //verifie si la zone trouver a le meme nom que celle retrouver
                       if (z.getNomZone() == zoneGeographique.getNomZone()){
                           //remplacement ra la nouvelle zone
                           zoneGeographiques.set(i, zoneGeographique);
                           break;

                       }


                   }
    }
    public void supprimerZoneGeographique(ZoneGeographique zoneGeographique){

        zoneGeographiques.remove(zoneGeographique);

    }


}